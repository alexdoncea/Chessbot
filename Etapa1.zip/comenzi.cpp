#include <cstdio>
#include <bits/stdc++.h>
#include "piese.h"

#define Alb true
#define Negru false

using namespace std;
bool culoare_de_verificat = Negru;
bool e_la_rand = Alb;

class Moves{
    public:
        Moves(){

        }

        //muta pentru calculator dand de ex comanda move e4e5 pentru xboard
        void move(char initialX, int initialY, char finalX, int finalY){
            cout << "move " << initialX << initialY << finalX << finalY << "\n";
        }
};

class Commands{
    public:
        char command[20];

        Commands(){

        }

        Commands(char command[20]){
            strncpy(this->command, command, 20);
        }

        //aici bagam toate comenzile ce pot veni de la xboard sau trebuiesc date la xboard
        static void parse_instruction(char instruction[1024]){
            if (strstr(instruction, "resign")){
                cout << "resign\n";
            }

            if (strstr(instruction, "protover")){
                cout << "feature san=0 sigint=0\n";
            }

            if (strstr(instruction, "black")){
                culoare_de_verificat = Negru;
            }

            if (strstr(instruction, "white")){
                culoare_de_verificat = Alb;
            }
        }
};

//Functia care muta pentru calculator bazandu-se pe miscarile posibile din matrice
Piesa*** go_instruction(Piesa*** chessboard){
    Moves move;
    //Schimbam culoarea deoarece dupa ce am facut noi mutarea urmeaza mutarea culorii opuse si cream 2 vectori pentru posibilele mutari
    e_la_rand = !e_la_rand;
    vector<pair<int, char>> mutari{};
    vector<pair<int, int>> plecare{};

    for (size_t i = 1; i <= 8; i++){
        for (size_t j = 1; j <= 8; j++){
            vector<pair<int, char>> temp{};
            //Aici facem verificarile posibile pe care le poate face pionii/pionul daca este aproape de liniile 1/8 si le inregistram in acei 2 vectori creati mutari&plecare
            if (culoare_de_verificat == chessboard[i][j]->culoare && chessboard[i][j]->tip == 'p')
                temp = chessboard[i][j]->verifica_posibile(chessboard);

            for (size_t k = 0; k < temp.size(); k++){
                mutari.push_back(temp[k]);
                plecare.push_back(make_pair(i, j));
            }
        }
    }
    //Aici verificam mai intai daca avem mutari posibile pentru a face mutarea calculatorului fie dam resign in caz contrar
    if (mutari.size() != 0 && plecare.size() != 0){
        move.move(index_letter(plecare[0].second), plecare[0].first, mutari[0].second, mutari[0].first);
        chessboard[plecare[0].first][plecare[0].second]->muta(make_pair(plecare[0].first, index_letter(plecare[0].second)), make_pair(mutari[0].first, mutari[0].second), chessboard);
        e_la_rand = !e_la_rand;
    }
    else{
        cout << "resign\n";
    }
    return chessboard;
}

//Functia de dealocare a memoriei a matricei existente
Piesa*** deallocation(Piesa*** chessboard){
    for (size_t i = 1; i <= 8; i++){
        for (size_t j = 1; j <= 8; j++){
            delete chessboard[i][j];
        }
    }

    for (size_t i = 0; i < 10; i++){
        delete[] chessboard[i];
    }

    delete[] chessboard;
    return chessboard;
}

//Instructiunea New Game in care apelam functia deallocation si apoi cream o matrice noua
Piesa*** new_game(Piesa*** chessboard){
    deallocation(chessboard);
    chessboard = new Piesa **[10];

    for (size_t i = 0; i < 10; i++){
        chessboard[i] = new Piesa *[10];
    }
    set_board(chessboard);
    culoare_de_verificat = Negru;
    e_la_rand = Alb;
    cout << "variant 3check\n";

    return chessboard;
}

int main()
{
    char *resigne = (char *)malloc(7 * sizeof(*resigne));
    strcpy(resigne, "resign");
    char *variante = (char *)malloc(15 * sizeof(*variante));
    strcpy(variante, "variant 3check");
    Commands resign(resigne), variant(variante);
    free(variante);
    free(resigne);

    //Alocam memorie pentru tabla de joc si setam piesele pe ea.
    Piesa ***chessboard = new Piesa **[10];
    for (size_t i = 0; i < 10; i++){
        chessboard[i] = new Piesa *[10];
    }
    set_board(chessboard);
    Moves move;
    char instruction[1024];

    //Acest while este partea principala a codului, aici se primesc instructiunile si se fac toate comenzile necesare jocului.
    while (1){
        //Primim instructiunile fie scrise in terminal fie transmise prin intermediul xboard-ului
        cin.getline(instruction, 1024);
        //Verificam daca in stringul de mai sus nu este vre-o instructiune care se afla in clasa Commands
        Commands::parse_instruction(instruction);
        //Aici verificam daca al doilea caracter din instructiune este o cifra pentru a face in matricea creata de noi aceleasi mutari pe care le facem si in xboard
        if (isdigit(instruction[1])){
            //aceasta instructiune chessboar[i][j]->muta este pentru a marca in matrice mutarea
            chessboard[instruction[1] - '0'][letter_index(instruction[0])]->muta(make_pair(instruction[1] - '0', instruction[0]), make_pair(instruction[3] - '0', instruction[2]), chessboard);
            chessboard = go_instruction(chessboard);
        }
        else if ((e_la_rand == culoare_de_verificat) && (strstr(instruction, "go"))){
            printf("am intrat ->  %s\n", instruction);
            chessboard = go_instruction(chessboard);
        }

        //Instructiunea new unde stergem matricea existenta si cream alta noua
        if (strstr(instruction, "new")){
            chessboard = new_game(chessboard);
        }

        if (strstr(instruction, "force")){
            while (2){

                //Citim instructiunile de la tastatura fie date de xboard si le verficam cu clasa Commands
                cin.getline(instruction, 1024);
                Commands::parse_instruction(instruction);

                //Inregistram fiecare miscare in matricea noastra facuta in force mode
                if (isdigit(instruction[1])){
                    e_la_rand = !e_la_rand;
                    chessboard[instruction[1] - '0'][letter_index(instruction[0])]->muta(make_pair(instruction[1] - '0', instruction[0]), make_pair(instruction[3] - '0', instruction[2]), chessboard);
                }

                if (strstr(instruction, "quit")){
                    chessboard = deallocation(chessboard);
                    return 0;
                }

                if (strstr(instruction, "go")){
                    chessboard = go_instruction(chessboard);
                    break;
                }

                if (strstr(instruction, "new")){
                    chessboard = new_game(chessboard);
                    break;
                }
            }
        }

        //Instructiunea quit in care dealocam memoria din matrice si iesim din while
        if (strstr(instruction, "quit")){
            chessboard = deallocation(chessboard);
            break;
        }
    }
    return 0;
}