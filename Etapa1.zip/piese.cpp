#include <iostream>
#include <vector>
#include "piese.h"

#define Alb true
#define Negru false

using namespace std;

//functie care returneaza indexul corespunzator literei (axa x pe tabla de joc, am presupus ca le vom nota cu litere mici)
int letter_index (char c){
    return c - 'a' + 1;
}

//avand un index, functia returneaza litera corespunzatoare
char index_letter (int n){
    return static_cast <char> (n + 96);
}

//functie care elimina o piesa de pe tabla
void clear_piece (Piesa* obj){
    obj->culoare = false;
    obj->pozitie = make_pair(0, 0);
    obj->prima = true;
    obj->tip = '0';
}

//functie care copiaza o piesa
void copy_piece (Piesa* obj1, Piesa* obj2){
    obj1->culoare = obj2->culoare;
    obj1->pozitie = obj2->pozitie;
    obj1->prima = obj2->prima;
    obj1->tip = obj2->tip;

    clear_piece(obj1);
}

//Se apeleaza la joc nou / comanda new
//Pune tabla de joc la setup-ul initial
void set_board (Piesa*** board){
    //Asezare piese albe
    board[1][1] = new Tura(make_pair(1, 'a'), Alb);
    board[1][2] = new Cal(make_pair(1, 'b'), Alb);
    board[1][3] = new Nebun(make_pair(1, 'c'), Alb);
    board[1][4] = new Regina(make_pair(1, 'd'), Alb);
    board[1][5] = new Rege(make_pair(1, 'e'), Alb);
    board[1][6] = new Nebun(make_pair(1, 'f'), Alb);
    board[1][7] = new Cal(make_pair(1, 'g'), Alb);
    board[1][8] = new Tura(make_pair(1, 'h'), Alb);

    for (int i = 1; i <= 8; i++)
        board[2][i] = new Pion(make_pair(2, index_letter(i)), Alb);
    
    //Asezare piese negre
    board[8][1] = new Tura(make_pair(8, 'a'), Negru);
    board[8][2] = new Cal(make_pair(8, 'b'), Negru);
    board[8][3] = new Nebun(make_pair(8, 'c'), Negru);
    board[8][4] = new Regina(make_pair(8, 'd'), Negru);
    board[8][5] = new Rege(make_pair(8, 'e'), Negru);
    board[8][6] = new Nebun(make_pair(8, 'f'), Negru);
    board[8][7] = new Cal(make_pair(8, 'g'), Negru);
    board[8][8] = new Tura(make_pair(8, 'h'), Negru);

    for (int i = 1; i <= 8; i++)
        board[7][i] = new Pion(make_pair(7, index_letter(i)), Negru);
    
    for (size_t i = 3; i <= 6; i++)
        for (size_t j = 1; j <= 8; j++)
            board[i][j] = new Piesa(make_pair(i, index_letter(j)));
}

/* ---------- Piesa ----------*/
/*
Functia check e folosita in principal pe board
c - culoarea piesei care apeleaza functia
Return values:
1 - loc gol
2 - piesa de culoare opusa
3 - rege de culoare opusa
0 - piesa de aceeasi culoare
*/
// board[3][1]->check(Alb);
int Piesa::check(bool c){
    if(this->tip == '0'){
        return 1;
    } else {
        if(this->culoare != c){
            if(this->tip != 'r'){
                return 2;
            } else {
                return 3;
            }
        } else {
            return 0;
        }
    }
}

Piesa::Piesa(){}
Piesa::~Piesa(){}

Piesa::Piesa(pair<int, char> pozitie){
    this->pozitie = pozitie;
}

Piesa::Piesa(pair<int, char> pozitie, bool culoare){
    this->pozitie = pozitie;
    this->culoare = culoare;
}

Piesa::Piesa(pair<int, char> pozitie, bool culoare, char tip){
    this->pozitie = pozitie;
    this->culoare = culoare;
    this->tip = tip;
}

void Piesa::seteaza_tip(char tip){
    this->tip = tip;
}


// bool Piesa::muta(pair<int, char> src, pair<int, char> dest, Piesa ***board){
//  return false;
// }

vector<pair<int, char>> Piesa::verifica_posibile(Piesa*** board){
    vector<pair<int, char>> temp{};
    return temp;
}

void Piesa::afiseaza_tip(){
    cout << "0\n";
}

/* ---------- Pion ----------*/
void Pion::afiseaza_tip(){
    cout << "p\n";
}

Pion::Pion() : Piesa(){
    seteaza_tip('p');
}

Pion::Pion(pair<int, char> pozitie) : Piesa(pozitie){
    seteaza_tip('p');
}

Pion::Pion(pair<int, char> pozitie, bool culoare) : Piesa(pozitie, culoare, 'p'){}

vector<pair<int, char>> Pion::verifica_posibile(Piesa*** board) {
    vector<pair<int, char>> temp{};
    if(!this->culoare){ // pionul se muta in feluri diferite daca e negru sau alb, aici tratez pentru negru
        if(this->prima){ //daca e prima data cand se muta pionul se poate muta cu 2 in fata
            if(board[this->pozitie.first - 2][letter_index(this->pozitie.second)]->check(this->culoare) == 1 && 
                board[this->pozitie.first - 1][letter_index(this->pozitie.second)]->check(this->culoare) == 1)
                temp.push_back(make_pair(this->pozitie.first - 2, this->pozitie.second));
        }

        //caz normal, se muta 1 in fata
        if(this->pozitie.first - 1 >= 1)
            if(board[this->pozitie.first - 1][letter_index(this->pozitie.second)]->check(this->culoare) == 1)
                temp.push_back(make_pair(this->pozitie.first - 1, this->pozitie.second));

        //caz de atac
        if(letter_index(this->pozitie.second) - 1 >= 1 && this->pozitie.first - 1 >= 1) // daca nu ies de pe tabla in lateral
            if(board[this->pozitie.first - 1][letter_index(this->pozitie.second) - 1]->check(this->culoare) == 2) //trebuie sa fie ocupata pozitia de atac cu piesa de culoare opusa
                temp.push_back(make_pair(this->pozitie.first - 1, index_letter(letter_index(this->pozitie.second) - 1)));
        
        if(letter_index(this->pozitie.second) + 1 <= 8 && this->pozitie.first - 1 >= 1) // daca nu ies de pe tabla in lateral
            if(board[this->pozitie.first - 1][letter_index(this->pozitie.second) + 1]->check(this->culoare) == 2)
                temp.push_back(make_pair(this->pozitie.first - 1, index_letter(letter_index(this->pozitie.second) + 1)));
    } 
    else {
        if(prima){ //daca e prima data cand se muta pionul se poate muta cu 2 in fata
            if(board[this->pozitie.first + 2][letter_index(this->pozitie.second)]->check(this->culoare) == 1 &&
                    board[this->pozitie.first + 1][letter_index(this->pozitie.second)]->check(this->culoare) == 1)
                temp.push_back(make_pair(this->pozitie.first + 2, this->pozitie.second));
        }

        //caz normal, se muta 1 in fata
        if(this->pozitie.first + 1 <= 8)
            if(board[this->pozitie.first + 1][letter_index(this->pozitie.second)]->check(this->culoare) == 1)
                temp.push_back(make_pair(this->pozitie.first + 1, this->pozitie.second));

        //caz de atac
        if(letter_index(this->pozitie.second)-1 >= 1 && this->pozitie.first + 1 <= 8) // daca nu ies de pe tabla in lateral
            if(board[this->pozitie.first + 1][letter_index(this->pozitie.second) - 1]->check(this->culoare) == 2) //trebuie sa fie ocupata pozitia de atac cu piesa de culoare opusa
                temp.push_back(make_pair(this->pozitie.first + 1, index_letter(letter_index(this->pozitie.second) - 1)));
        
        if(letter_index(this->pozitie.second) + 1 <= 8 && this->pozitie.first + 1 <= 8) // daca nu ies de pe tabla in lateral
            if(board[this->pozitie.first + 1][letter_index(this->pozitie.second)+1]->check(this->culoare) == 2)
                temp.push_back(make_pair(this->pozitie.first + 1, index_letter(letter_index(this->pozitie.second) + 1)));
    }
    return temp;
}

bool Piesa::muta(pair<int, char> src, pair<int, char> dest, Piesa ***board) {
    //apelez muta pe un obiect pion pe care il sterg in aceasta functie, nu cred ca e prea corect :)))
    delete board[dest.first][letter_index(dest.second)];

    board[dest.first][letter_index(dest.second)] = new Pion(dest, board[src.first][letter_index(src.second)]->culoare);
    board[dest.first][letter_index(dest.second)]->prima = false;

    delete board[src.first][letter_index(src.second)];

    board[src.first][letter_index(src.second)] = new Piesa(src);

    if((dest.first == 1 || dest.first == 8)&& board[dest.first][letter_index(dest.second)]->tip == 'p')
        Pion::upgrade('q', dest, board);

    return false;
}

//de implementat upgrade dupa ce fac regina
//dupa ce pe board am un alt obiect, pionul care a ajuns acolo si nu mai e in board inca exista in memorie
//pot face un ~Pion() (deconstructor) si apelez acolo unde am dat comanda de upgrade??
void Pion::upgrade(char tip, pair<int, char> poz, Piesa ***board){
        bool temp_c = board[poz.first][letter_index(poz.second)]->culoare;
        delete board[poz.first][letter_index(poz.second)];
        board[poz.first][letter_index(poz.second)] = new Regina(poz, temp_c);
        board[poz.first][letter_index(poz.second)]->prima = false;
        // switch(tip){
        //     case 'c':
        //         board[this->pozitie.second][letter_index(this->pozitie.first)] = Cal(this->pozitie, this->culoare);
        //         break;
        //     case 'n':
        //         board[this->pozitie.second][letter_index(this->pozitie.first)] = Nebun(this->pozitie, this->culoare);
        //         break;
        //     case 't':
        //         board[this->pozitie.second][letter_index(this->pozitie.first)] = Tura(this->pozitie, this->culoare);
        //         break;
        //     default:
        //         board[this->pozitie.second][letter_index(this->pozitie.first)] = Regina(this->pozitie, this->culoare);
        //         break;
        // }
    // }
}

/* ---------- Cal ----------*/

Cal::Cal() : Piesa(){
    seteaza_tip('c');
}

Cal::Cal(pair<int, char> pozitie) : Piesa(pozitie){
    seteaza_tip('c');
}

Cal::Cal(pair<int, char> pozitie, bool culoare) : Piesa(pozitie, culoare, 'c'){}

// bool Cal::muta(pair<int, char> src, pair<int, char> dest, Piesa ***board){
//     //de implementat, basically the same, poate ramane doar la piesa si scoatem virtual
//     return false;
// }

vector<pair<int, char>> Cal::verifica_posibile(Piesa*** board){
    //de implementat, nu conteaza culoarea, sunt acelasi 8 pozitii de verificat si pt alb si negru, si odar pozitiile alea, nu is drumul(calul poate sarii)
    vector<pair<int, char>> temp{};
    return temp;
}

/* ---------- Nebun ----------*/

Nebun::Nebun() : Piesa(){
    seteaza_tip('n');
}

Nebun::Nebun(pair<int, char> pozitie) : Piesa(pozitie){
    seteaza_tip('n');
}

Nebun::Nebun(pair<int, char> pozitie, bool culoare) : Piesa(pozitie, culoare, 'n'){}

// bool Nebun::muta(pair<int, char> src, pair<int, char> dest, Piesa ***board){
//     //de implementat, basically the same, poate ramane doar la piesa si scoatem virtual
//     return false;
// }

vector<pair<int, char>> Nebun::verifica_posibile(Piesa*** board){
    //de implementat, nu conteaza culoarea, va fi un for si 4 bool(fata-st, fata-dr, spate-st, spate-dr)
    //care merge cu un singur indice si verifica toate cele 4 directii , iar cand da de un blocaj bool-ul resp se dupe pe false
    vector<pair<int, char>> temp{};
    return temp;
}

/* ---------- Regina ----------*/

Regina::Regina() : Piesa(){
    seteaza_tip('q');
}

Regina::Regina(pair<int, char> pozitie) : Piesa(pozitie){
    seteaza_tip('q');
}

Regina::Regina(pair<int, char> pozitie, bool culoare) : Piesa(pozitie, culoare, 'q'){}

// bool Regina::muta(pair<int, char> src, pair<int, char> dest, Piesa ***board){
//     //de implementat, basically the same, poate ramane doar la piesa si scoatem virtual
//     return false;
// }

vector<pair<int, char>> Regina::verifica_posibile(Piesa*** board){
    //nu ma duce capul momentan
    vector<pair<int, char>> temp{};
    return temp;
}

//de vazut pentru upgrade

/* ---------- Tura ----------*/

Tura::Tura() : Piesa(){
    seteaza_tip('t');
}

Tura::Tura(pair<int, char> pozitie) : Piesa(pozitie){
    seteaza_tip('t');
}

Tura::Tura(pair<int, char> pozitie, bool culoare) : Piesa(pozitie, culoare, 't'){}

// bool Tura::muta(pair<int, char> src, pair<int, char> dest, Piesa ***board){
//     //de implementat, basically the same, poate ramane doar la piesa si scoatem virtual
//     //la prima mutare, prima devina false
//     return false;
// }

vector<pair<int, char>> Tura::verifica_posibile(Piesa*** board){
    vector<pair<int, char>> temp{};
    return temp;
}

/* ---------- Rege ----------*/

Rege::Rege() : Piesa(){
    seteaza_tip('r');
}

Rege::Rege(pair<int, char> pozitie) : Piesa(pozitie){
    seteaza_tip('r');
}

Rege::Rege(pair<int, char> pozitie, bool culoare) : Piesa(pozitie, culoare, 'r'){}

// bool Rege::muta(pair<int, char> src, pair<int, char> dest, Piesa ***board){
//     //de implementat, basically the same, poate ramane doar la piesa si scoatem virtual
//     //la prima mutare, prima devina false
//     return false;
// }

vector<pair<int, char>> Rege::verifica_posibile(Piesa*** board){
    // cam ca la pion, dar si in spate si in fata, trebuie verificat si daca nu se intra in sah
    //caz special, se apeleaza verifica_roacada si se adauga cumva in vectorul de posibilitati??
    vector<pair<int, char>> temp{};
    return temp;
}

bool Rege::verifica_rocada(char tip, Piesa*** board){
    if(tip == 'm'){ //rocada mica
        bool gol = true;
        for(int i = 1; i <= 2; i++){
            if(board[this->pozitie.first][letter_index(this->pozitie.second) + i]->check(this->culoare) != 1)
                gol = false;
        }
        return (gol && this->prima && board[this->pozitie.first][letter_index('h')]->prima); //daca tura nu e la locul ei nu merge
    } 
    else {// adica 'M', rocada mare
        bool gol = true;
        for(int i = 1; i <= 3; i++){
            if(board[this->pozitie.first][letter_index(this->pozitie.second) - i]->check(this->culoare) != 1)
                gol = false;
        }
        return (gol && this->prima && board[this->pozitie.first][letter_index('a')]->prima); //daca tura nu e la locul ei nu merge
    }
}